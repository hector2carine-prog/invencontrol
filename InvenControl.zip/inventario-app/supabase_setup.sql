-- ═══════════════════════════════════════════════════════
--  INVENTARIO PRO — Supabase SQL Setup v2 (con Lugares)
--  Ejecutar en: SQL Editor → New query → Run
-- ═══════════════════════════════════════════════════════

-- 1. USUARIOS
CREATE TABLE IF NOT EXISTS public.usuarios (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre       TEXT NOT NULL,
  usuario      TEXT NOT NULL UNIQUE,
  pass_hash    TEXT NOT NULL,
  rol          TEXT NOT NULL DEFAULT 'viewer' CHECK (rol IN ('admin','editor','viewer')),
  activo       BOOLEAN DEFAULT TRUE,
  creado_at    TIMESTAMPTZ DEFAULT NOW(),
  ultimo_login TIMESTAMPTZ
);

-- 2. LUGARES
CREATE TABLE IF NOT EXISTS public.lugares (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre      TEXT NOT NULL UNIQUE,
  descripcion TEXT,
  icono       TEXT DEFAULT 'ti-building-warehouse',
  color       TEXT DEFAULT '#111111',
  orden       INTEGER DEFAULT 0,
  creado_at   TIMESTAMPTZ DEFAULT NOW()
);

-- 3. ARTÍCULOS (con lugar_id)
CREATE TABLE IF NOT EXISTS public.articulos (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lugar_id       UUID REFERENCES public.lugares(id) ON DELETE SET NULL,
  codigo         TEXT,
  nombre         TEXT NOT NULL,
  categoria      TEXT,
  cantidad       INTEGER DEFAULT 1,
  estado         TEXT DEFAULT 'Operativo' CHECK (estado IN ('Operativo','Mantención','Revisión','Dado de baja')),
  precio         NUMERIC,
  fecha_adq      DATE,
  observaciones  TEXT,
  creado_por     TEXT,
  creado_at      TIMESTAMPTZ DEFAULT NOW(),
  actualizado_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. FOTOS
CREATE TABLE IF NOT EXISTS public.fotos (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  articulo_id  UUID NOT NULL REFERENCES public.articulos(id) ON DELETE CASCADE,
  storage_path TEXT NOT NULL,
  url          TEXT,
  orden        INTEGER DEFAULT 0,
  creado_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 5. RLS
ALTER TABLE public.usuarios  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lugares   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articulos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fotos     ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='usuarios'  AND policyname='all_usuarios')  THEN CREATE POLICY all_usuarios  ON public.usuarios  FOR ALL USING (true) WITH CHECK (true); END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='lugares'   AND policyname='all_lugares')   THEN CREATE POLICY all_lugares   ON public.lugares   FOR ALL USING (true) WITH CHECK (true); END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='articulos' AND policyname='all_articulos') THEN CREATE POLICY all_articulos ON public.articulos FOR ALL USING (true) WITH CHECK (true); END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='fotos'     AND policyname='all_fotos')     THEN CREATE POLICY all_fotos     ON public.fotos     FOR ALL USING (true) WITH CHECK (true); END IF;
END $$;

-- 6. STORAGE
INSERT INTO storage.buckets (id, name, public)
VALUES ('inventario-fotos','inventario-fotos',true)
ON CONFLICT (id) DO NOTHING;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='objects' AND policyname='read_fotos')   THEN CREATE POLICY read_fotos   ON storage.objects FOR SELECT USING (bucket_id='inventario-fotos'); END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='objects' AND policyname='upload_fotos') THEN CREATE POLICY upload_fotos ON storage.objects FOR INSERT WITH CHECK (bucket_id='inventario-fotos'); END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='objects' AND policyname='delete_fotos') THEN CREATE POLICY delete_fotos ON storage.objects FOR DELETE USING (bucket_id='inventario-fotos'); END IF;
END $$;

-- 7. LUGARES INICIALES
INSERT INTO public.lugares (nombre, descripcion, icono, color, orden) VALUES
  ('Bodega 1',   'Almacén principal',         'ti-building-warehouse', '#111111', 1),
  ('Bodega 2',   'Almacén secundario',         'ti-building-warehouse', '#444444', 2),
  ('Oficina',    'Equipos de oficina',         'ti-building',           '#185FA5', 3),
  ('Taller',     'Herramientas y reparación',  'ti-tool',               '#C07A10', 4),
  ('Vehículo 1', 'Camioneta / vehículo 1',     'ti-truck',              '#1A8A5A', 5)
ON CONFLICT (nombre) DO NOTHING;

-- 8. USUARIOS INICIALES
INSERT INTO public.usuarios (nombre, usuario, pass_hash, rol) VALUES
  ('Administrador','admin',  'placeholder_admin',  'admin'),
  ('Editor',       'editor', 'placeholder_editor', 'editor')
ON CONFLICT (usuario) DO NOTHING;

-- ✓ Listo — tablas: usuarios, lugares, articulos, fotos

-- ═══════════════════════════════════════════════════
--  MÓDULO ENTRADAS / SALIDAS — Agregar al SQL existente
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.movimientos (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  articulo_id  UUID NOT NULL REFERENCES public.articulos(id) ON DELETE CASCADE,
  tipo         TEXT NOT NULL CHECK (tipo IN ('entrada','salida')),
  cantidad     INTEGER NOT NULL CHECK (cantidad > 0),
  motivo       TEXT,                        -- ej: "Compra", "Préstamo", "Devolución"
  responsable  TEXT,                        -- quién lo retira/ingresa
  destino      TEXT,                        -- a dónde va (salida) o de dónde viene (entrada)
  notas        TEXT,
  registrado_por TEXT,
  creado_at    TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.movimientos ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='movimientos' AND policyname='all_movimientos')
  THEN CREATE POLICY all_movimientos ON public.movimientos FOR ALL USING (true) WITH CHECK (true); END IF;
END $$;
