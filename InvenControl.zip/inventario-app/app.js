// ── Detector de errores global ──
window.addEventListener('error', function(e){
  document.getElementById('splash').style.display='none';
  document.getElementById('login').style.display='none';
  document.body.innerHTML = `
    <div style="padding:30px;font-family:sans-serif;max-width:400px;margin:0 auto">
      <h2 style="color:#C0281A;margin-bottom:12px">⚠️ Error al cargar</h2>
      <p style="margin-bottom:8px;font-size:14px"><strong>Mensaje:</strong> ${e.message}</p>
      <p style="font-size:13px;color:#666"><strong>Archivo:</strong> ${e.filename}</p>
      <p style="font-size:13px;color:#666"><strong>Línea:</strong> ${e.lineno}</p>
      <div style="margin-top:20px;padding:14px;background:#f5f5f5;border-radius:8px;font-size:12px;word-break:break-all">
        <strong>URL Supabase:</strong><br>${typeof SUPABASE_URL !== 'undefined' ? SUPABASE_URL : 'NO DEFINIDA'}<br><br>
        <strong>Key:</strong><br>${typeof SUPABASE_ANON !== 'undefined' ? SUPABASE_ANON.slice(0,30)+'...' : 'NO DEFINIDA'}
      </div>
      <button onclick="location.reload()" style="margin-top:16px;padding:10px 20px;background:#111;color:#fff;border:none;border-radius:8px;cursor:pointer">Reintentar</button>
    </div>`;
});
'use strict';
// ═══════════════════════════════════════════════════
//  INVENTARIO PRO v2 — Con sistema de Lugares
// ═══════════════════════════════════════════════════

const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON);

async function sha256(t){
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t));
  return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');
}

let currentUser=null, inventory=[], lugares=[], addPhotos=[];
let catFilter='', estFilter='', lugarCatFilter='', lugarEstFilter='';
let currentLugar=null, editingId=null, modalItemId=null;
let qrModalInst=null, qrFormInst=null;
let scanStream=null, scanActive=false, scanInterval=null, scanForFieldCb=null;
let loginTries=0, lockUntil=0;
const MAX_TRIES=5, LOCK_MS=5*60*1000;

// ── ARRANQUE ──────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  const raw=sessionStorage.getItem('inv_session');
  if(raw){ try{ currentUser=JSON.parse(raw); await launchApp(); return; }catch{ sessionStorage.removeItem('inv_session'); } }
  setTimeout(()=>{
    document.getElementById('splash').style.display='none';
    document.getElementById('login').style.display='flex';
    document.getElementById('lp').addEventListener('keydown',e=>{ if(e.key==='Enter') doLogin(); });
    document.getElementById('lu').addEventListener('keydown',e=>{ if(e.key==='Enter') document.getElementById('lp').focus(); });
  },800);
});

// ── LOGIN ─────────────────────────────────────────
function togglePass(){ const i=document.getElementById('lp'),e=document.getElementById('eye'); i.type=i.type==='password'?'text':'password'; e.className=i.type==='password'?'ti ti-eye':'ti ti-eye-off'; }

async function doLogin(){
  if(Date.now()<lockUntil){ showLocked(); return; }
  const usuario=(document.getElementById('lu').value||'').trim().toLowerCase();
  const pass=document.getElementById('lp').value||'';
  if(!usuario||!pass){ showLoginErr('Completa usuario y contraseña.'); return; }
  const btn=document.getElementById('btn-login');
  btn.disabled=true; btn.textContent='Verificando...';
  try {
    const {data,error}=await sb.from('usuarios').select('*').eq('usuario',usuario).eq('activo',true).limit(1);
    if(error) throw error;
    let ok=false,user=null;
    if(data&&data.length){
      user=data[0]; const h=await sha256(pass); ok=h===user.pass_hash;
      if(!ok){ const def={admin:'Admin123*',editor:'Editor123*'}; if(def[usuario]&&pass===def[usuario]){ await sb.from('usuarios').update({pass_hash:h}).eq('id',user.id); user.pass_hash=h; ok=true; } }
      if(ok) await sb.from('usuarios').update({ultimo_login:new Date().toISOString()}).eq('id',user.id);
    }
    btn.disabled=false; btn.innerHTML='<i class="ti ti-login"></i> Ingresar';
    if(!ok){
      loginTries++;
      if(loginTries>=MAX_TRIES){ lockUntil=Date.now()+LOCK_MS; loginTries=0; showLocked(); }
      else{ const r=MAX_TRIES-loginTries; showLoginErr(`Incorrecto. ${r} intento${r!==1?'s':''} restante${r!==1?'s':''}.`); }
      if(navigator.vibrate) navigator.vibrate([60,30,60]); return;
    }
    loginTries=0; currentUser=user; sessionStorage.setItem('inv_session',JSON.stringify(user));
    document.getElementById('lerr').style.display='none'; document.getElementById('llocked').style.display='none';
    await launchApp();
  } catch(e){ btn.disabled=false; btn.innerHTML='<i class="ti ti-login"></i> Ingresar'; showLoginErr('Error de conexión.'); console.error(e); }
}
function showLoginErr(m){ document.getElementById('lerr').style.display='flex'; document.getElementById('lerr-txt').textContent=m; document.getElementById('llocked').style.display='none'; }
function showLocked(){
  const upd=()=>{ const s=Math.max(0,Math.ceil((lockUntil-Date.now())/1000)),m=Math.floor(s/60); document.getElementById('llocked-txt').textContent=`Bloqueado. Espera ${m>0?m+'m ':''}${s%60}s.`; if(s<=0) clearInterval(t); };
  document.getElementById('llocked').style.display='flex'; document.getElementById('lerr').style.display='none'; upd(); const t=setInterval(upd,1000);
}

// ── LAUNCH APP ────────────────────────────────────
async function launchApp(){
  document.getElementById('splash').style.display='none'; document.getElementById('login').style.display='none';
  const ini=currentUser.nombre.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  document.getElementById('avatar-initials').textContent=ini;
  document.getElementById('um-name').textContent=currentUser.nombre;
  document.getElementById('um-role').textContent=roleLabel(currentUser.rol);
  if(currentUser.rol==='admin'){
    document.getElementById('um-users-btn').style.display='flex';
    document.getElementById('um-lugares-btn').style.display='flex';
    document.getElementById('btn-add-lugar').style.display='flex';
  }
  if(currentUser.rol!=='viewer') document.getElementById('fab-add-art').style.display='none'; // se muestra solo en lugar-detail
  document.getElementById('app').style.display='block';
  await Promise.all([loadLugares(), loadInventory()]);
  updateCount(); fillDataLists(); goScreen('lugares');
}
function roleLabel(r){ return {admin:'Administrador',editor:'Editor',viewer:'Solo lectura'}[r]||r; }

// ── LOGOUT ────────────────────────────────────────
function doLogout(){
  stopScan(); currentUser=null; inventory=[]; lugares=[]; sessionStorage.removeItem('inv_session'); closeUM();
  document.getElementById('app').style.display='none'; document.getElementById('login').style.display='flex';
  document.getElementById('lu').value=''; document.getElementById('lp').value=''; document.getElementById('lerr').style.display='none';
}

// ── DATOS ─────────────────────────────────────────
async function loadLugares(){ const {data,error}=await sb.from('lugares').select('*').order('orden'); if(!error) lugares=data||[]; }

async function loadInventory(){
  const {data,error}=await sb.from('articulos').select('*, fotos(id,storage_path,url,orden), lugares(id,nombre,icono,color)').order('creado_at',{ascending:false});
  if(error){ console.error(error); return; }
  inventory=(data||[]).map(a=>({...a, fotos:(a.fotos||[]).sort((x,y)=>x.orden-y.orden).map(f=>f.url||storageUrl(f.storage_path)), lugar_nombre:a.lugares?.nombre||null, lugar_icono:a.lugares?.icono||null, lugar_color:a.lugares?.color||null }));
}
function storageUrl(path){ return `${SUPABASE_URL}/storage/v1/object/public/${STORAGE_BUCKET}/${path}`; }
function updateCount(){ document.getElementById('hdr-count').textContent=inventory.length; }

// ── NAVEGACIÓN ────────────────────────────────────
const SCREEN_MAP={
  lugares:        {id:'s-lugares',        title:'Lugares',          sub:'Selecciona un lugar',    nav:'nb-lugares'},
  'lugar-detail': {id:'s-lugar-detail',   title:'...',              sub:'...',                    nav:null},
  inventory:      {id:'s-inventory',      title:'Inventario',       sub:'Todos los artículos',    nav:'nb-inventory'},
  scan:           {id:'s-scan',           title:'Escanear QR',      sub:'Apunta al código',       nav:null},
  add:            {id:'s-add',            title:'Agregar artículo', sub:'Nuevo registro',         nav:null},
  stats:          {id:'s-stats',          title:'Estadísticas',     sub:'Resumen del inventario', nav:'nb-stats'},
  users:          {id:'s-users',          title:'Usuarios',         sub:'Gestión de acceso',      nav:null},
  'lugares-admin':{id:'s-lugares-admin',  title:'Lugares',          sub:'Gestión de lugares',     nav:null},
};
let screenHistory=['lugares'];

function goScreen(s){
  stopScan();
  const cfg=SCREEN_MAP[s]; if(!cfg) return;
  Object.values(SCREEN_MAP).forEach(c=>document.getElementById(c.id).classList.remove('active'));
  document.getElementById(cfg.id).classList.add('active');
  if(s!=='lugar-detail'){ document.getElementById('hdr-title').textContent=cfg.title; document.getElementById('hdr-sub').textContent=cfg.sub; }
  const isRoot=['lugares','inventory','stats'].includes(s);
  document.getElementById('hdr-back').style.display=isRoot?'none':'flex';
  document.querySelectorAll('.nb').forEach(b=>b.classList.remove('active'));
  if(cfg.nav) document.getElementById(cfg.nav).classList.add('active');
  document.getElementById('fab-add-art').style.display=(s==='lugar-detail'&&currentUser&&currentUser.rol!=='viewer')?'flex':'none';
  if(s==='lugares')        renderLugares();
  if(s==='inventory')      renderInventario();
  if(s==='scan')           startScan();
  if(s==='stats')          renderStats();
  if(s==='add'&&!editingId) resetForm();
  if(s==='lugares-admin')  { renderIconPicker(); renderColorPicker(); renderLugaresAdmin(); }
  screenHistory.push(s); closeUM();
}
function goBack(){ screenHistory.pop(); const prev=screenHistory[screenHistory.length-1]||'lugares'; goScreen(prev); }

// ── PANTALLA LUGARES ──────────────────────────────
function renderLugares(){
  document.getElementById('h-lugares').textContent=lugares.length;
  document.getElementById('h-total').textContent=inventory.length;
  document.getElementById('h-noOp').textContent=inventory.filter(i=>i.estado!=='Operativo').length;
  const grid=document.getElementById('lugares-grid');
  if(!lugares.length){ grid.innerHTML='<div class="empty-state"><i class="ti ti-map-pin"></i><p>Sin lugares creados.<br>Créalos desde el menú de usuario.</p></div>'; grid.className=''; return; }
  grid.className='lugares-grid';
  grid.innerHTML=lugares.map(l=>{
    const arts=inventory.filter(i=>i.lugar_id===l.id);
    const noOp=arts.filter(i=>i.estado!=='Operativo').length;
    const lc=hexToLight(l.color||'#111');
    const badge=!arts.length?`<span class="lc-badge lc-empty">Vacío</span>`:noOp>0?`<span class="lc-badge lc-warn">${noOp} alerta${noOp>1?'s':''}</span>`:`<span class="lc-badge lc-ok">Todo OK</span>`;
    return `<div class="lugar-card" style="--lc-color:${l.color||'#111'};--lc-color-l:${lc}" onclick="openLugar('${l.id}')">
      <div class="lc-icon-wrap"><i class="ti ${l.icono||'ti-building-warehouse'}" aria-hidden="true"></i></div>
      <div><div class="lc-name">${l.nombre}</div>${l.descripcion?`<div class="lc-desc">${l.descripcion}</div>`:''}</div>
      <div class="lc-footer"><span class="lc-count">${arts.length} artículo${arts.length!==1?'s':''}</span>${badge}</div>
    </div>`;
  }).join('');
}

// ── INTERIOR DE UN LUGAR ──────────────────────────
function openLugar(id){
  const lugar=lugares.find(l=>l.id===id); if(!lugar) return;
  currentLugar=lugar; lugarCatFilter=''; lugarEstFilter='';
  document.getElementById('hdr-title').textContent=lugar.nombre;
  document.getElementById('hdr-sub').textContent=lugar.descripcion||'Artículos en este lugar';
  document.getElementById('hdr-back').style.display='flex';
  const arts=inventory.filter(i=>i.lugar_id===lugar.id);
  const op=arts.filter(i=>i.estado==='Operativo').length, noOp=arts.length-op;
  const banner=document.getElementById('lugar-banner');
  banner.style.background=lugar.color||'#111';
  document.getElementById('lb-icon').innerHTML=`<i class="ti ${lugar.icono||'ti-building-warehouse'}" style="font-size:24px;color:${lugar.color||'#111'}" aria-hidden="true"></i>`;
  document.getElementById('lb-icon').style.background=hexToLight(lugar.color||'#111');
  document.getElementById('lb-name').textContent=lugar.nombre;
  document.getElementById('lb-desc').textContent=lugar.descripcion||'';
  document.getElementById('lb-stats').innerHTML=
    `<div class="lb-stat"><strong>${arts.length}</strong> artículos</div>`+
    (noOp>0?`<div class="lb-stat" style="color:#FFCC70"><strong>${noOp}</strong> no operativos</div>`:'<div class="lb-stat" style="color:#6DE8B2">Todo operativo ✓</div>');
  const cats=[...new Set(arts.map(i=>i.categoria).filter(Boolean))];
  document.getElementById('lugar-cat-chips').innerHTML=
    '<button class="chip active" onclick="setLugarCatFilter(\'\',this)">Todos</button>'+
    cats.map(c=>`<button class="chip" onclick="setLugarCatFilter('${c.replace(/'/g,"\\'")}',this)">${c}</button>`).join('');
  Object.values(SCREEN_MAP).forEach(c=>document.getElementById(c.id).classList.remove('active'));
  document.getElementById('s-lugar-detail').classList.add('active');
  document.querySelectorAll('.nb').forEach(b=>b.classList.remove('active'));
  document.getElementById('nb-lugares').classList.add('active');
  document.getElementById('fab-add-art').style.display=currentUser.rol!=='viewer'?'flex':'none';
  screenHistory.push('lugar-detail'); closeUM();
  document.getElementById('lugar-search').value='';
  renderLugarItems();
}

function setLugarCatFilter(v,el){ lugarCatFilter=v; document.querySelectorAll('#lugar-cat-chips .chip').forEach(c=>c.classList.remove('active')); el.classList.add('active'); renderLugarItems(); }
function setLugarEstFilter(v,el){ lugarEstFilter=v; document.querySelectorAll('.estado-chips .chip').forEach(c=>c.classList.remove('active')); el.classList.add('active'); renderLugarItems(); }

function renderLugarItems(){
  if(!currentLugar) return;
  const q=(document.getElementById('lugar-search').value||'').toLowerCase();
  const items=inventory.filter(i=>i.lugar_id===currentLugar.id&&(!lugarCatFilter||i.categoria===lugarCatFilter)&&(!lugarEstFilter||i.estado===lugarEstFilter)&&(!q||(i.nombre||'').toLowerCase().includes(q)||(i.codigo||'').toLowerCase().includes(q)));
  const body=document.getElementById('lugar-items-list');
  if(!items.length){ body.innerHTML=`<div class="empty-state"><i class="ti ti-box"></i><p>${inventory.filter(i=>i.lugar_id===currentLugar.id).length?'Sin resultados.':'Este lugar está vacío.<br>Toca + para agregar artículos.'}</p></div>`; return; }
  body.innerHTML=items.map(i=>itemCardHTML(i,false)).join('');
}

function addArtInLugar(){ goScreen('add'); setTimeout(()=>{ if(currentLugar) document.getElementById('a-lugar').value=currentLugar.id; },150); }

// ── INVENTARIO COMPLETO ───────────────────────────
function fillDataLists(){
  const cats=[...new Set(inventory.map(i=>i.categoria).filter(Boolean))];
  document.getElementById('cat-list').innerHTML=cats.map(c=>`<option value="${c}">`).join('');
  const sel=document.getElementById('a-lugar'); const prev=sel.value;
  sel.innerHTML='<option value="">Sin lugar asignado</option>'+lugares.map(l=>`<option value="${l.id}">${l.nombre}</option>`).join('');
  if(prev) sel.value=prev;
  const chips=document.getElementById('cat-chips');
  chips.innerHTML='<button class="chip active" onclick="setCatFilter(\'\',this)">Todos</button>'+cats.map(c=>`<button class="chip" onclick="setCatFilter('${c.replace(/'/g,"\\'")}',this)">${c}</button>`).join('');
}
function setCatFilter(v,el){ catFilter=v; document.querySelectorAll('#cat-chips .chip').forEach(c=>c.classList.remove('active')); el.classList.add('active'); renderInventario(); }
function setEstFilter(v,el){ estFilter=v; document.querySelectorAll('.estado-chips .chip').forEach(c=>c.classList.remove('active')); el.classList.add('active'); renderInventario(); }
function clearSearch(){ document.getElementById('inv-search').value=''; renderInventario(); }

function renderInventario(){
  const q=(document.getElementById('inv-search').value||'').toLowerCase();
  const body=document.getElementById('inv-list');
  const items=inventory.filter(i=>(!catFilter||i.categoria===catFilter)&&(!estFilter||i.estado===estFilter)&&(!q||(i.nombre||'').toLowerCase().includes(q)||(i.codigo||'').toLowerCase().includes(q)||(i.lugar_nombre||'').toLowerCase().includes(q)));
  if(!items.length){ body.innerHTML=`<div class="empty-state"><i class="ti ti-box"></i><p>${inventory.length?'Sin resultados.':'Sin artículos aún.'}</p></div>`; return; }
  body.innerHTML=items.map(i=>itemCardHTML(i,true)).join('');
}

function itemCardHTML(i,showLugar=false){
  const meta=showLugar?[i.lugar_nombre,i.categoria].filter(Boolean).join(' · ')||'—':[i.categoria||'—'];
  return `<div class="item-card" onclick="openDetail('${i.id}')">
    ${i.fotos&&i.fotos.length?`<img src="${i.fotos[0]}" class="item-card-img" alt="${i.nombre}" loading="lazy">`:`<div class="item-card-placeholder"><i class="ti ti-photo"></i></div>`}
    <div class="item-card-body">
      <div class="item-card-code">${i.codigo||'Sin código'}</div>
      <div class="item-card-name">${i.nombre}</div>
      <div class="item-card-meta">${meta}</div>
      <div class="item-card-footer">${estadoBadge(i.estado)}<span class="qty-tag">${i.cantidad} ud${i.cantidad!==1?'s':''}</span></div>
    </div>
  </div>`;
}
function estadoBadge(e){ const m={'Operativo':'e-op','Mantención':'e-mant','Revisión':'e-rev','Dado de baja':'e-baja'}; return `<span class="ebadge ${m[e]||'e-op'}">${e||'Operativo'}</span>`; }

// ── ESCÁNER QR ────────────────────────────────────
async function startScan(){
  const video=document.getElementById('scan-video'); document.getElementById('scan-result').style.display='none';
  try { scanStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment',width:{ideal:1280},height:{ideal:720}}}); video.srcObject=scanStream; scanActive=true; scanInterval=setInterval(()=>processFrame(video),200); }
  catch(e){ const r=document.getElementById('scan-result'); r.style.display='block'; r.style.background='var(--red-l)'; r.style.color='var(--red)'; r.textContent='No se pudo acceder a la cámara.'; }
}
function stopScan(){ scanActive=false; if(scanInterval){ clearInterval(scanInterval); scanInterval=null; } if(scanStream){ scanStream.getTracks().forEach(t=>t.stop()); scanStream=null; } }
function processFrame(video){
  if(!scanActive||video.readyState!==4) return;
  const canvas=document.createElement('canvas'); canvas.width=video.videoWidth; canvas.height=video.videoHeight;
  canvas.getContext('2d').drawImage(video,0,0);
  const img=canvas.getContext('2d').getImageData(0,0,canvas.width,canvas.height);
  const code=jsQR(img.data,img.width,img.height); if(code) onQRDetected(code.data);
}
function onQRDetected(data){
  stopScan(); if(navigator.vibrate) navigator.vibrate(100);
  if(scanForFieldCb){ scanForFieldCb(data); scanForFieldCb=null; goBack(); return; }
  let codigo=data; try{ const o=JSON.parse(data); codigo=o.codigo||o.serial||data; }catch{}
  const found=inventory.find(i=>i.codigo===codigo||(i.codigo&&data.includes(i.codigo)));
  if(found){ goBack(); setTimeout(()=>openDetail(found.id),300); }
  else {
    const res=document.getElementById('scan-result');
    res.style.display='block'; res.style.background='var(--amber-l)'; res.style.color='var(--amber)';
    res.innerHTML=`<i class="ti ti-qrcode" style="font-size:18px;vertical-align:-3px;margin-right:6px"></i>Código: <strong>${codigo}</strong><br><span style="font-size:12px">No encontrado en inventario.</span><br><button onclick="createFromScan('${codigo.replace(/'/g,"\\'")}',event)" style="margin-top:8px;padding:7px 14px;background:var(--ink);color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer">+ Agregar con este código</button>`;
  }
}
function createFromScan(codigo,e){ e.stopPropagation(); goScreen('add'); setTimeout(()=>{ document.getElementById('a-code').value=codigo; generateQRPreview(codigo); },300); }
function scanForField(){ scanForFieldCb=(data)=>{ let c=data; try{const o=JSON.parse(data);c=o.codigo||o.serial||data;}catch{}; document.getElementById('a-code').value=c; generateQRPreview(c); showToast('Código capturado'); }; goScreen('scan'); }
function toggleFlash(){ if(!scanStream) return; const track=scanStream.getVideoTracks()[0]; if(!track) return; const caps=track.getCapabilities(); if(!caps.torch){ showToast('Flash no disponible'); return; } track.applyConstraints({advanced:[{torch:!track.getSettings().torch}]}); }

// ── FORMULARIO ────────────────────────────────────
function resetForm(){
  editingId=null;
  ['a-code','a-name','a-cat','a-obs'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
  document.getElementById('a-qty').value='1'; document.getElementById('a-est').value='Operativo';
  document.getElementById('a-price').value=''; document.getElementById('a-date').value='';
  document.getElementById('a-lugar').value='';
  addPhotos=[]; renderPhotosGrid();
  document.getElementById('qr-preview-card').style.display='none'; document.getElementById('qr-gen-el').innerHTML='';
  document.getElementById('save-label').textContent='Guardar artículo';
  document.getElementById('hdr-title').textContent='Agregar artículo'; document.getElementById('hdr-sub').textContent='Nuevo registro';
}
function cancelForm(){ editingId=null; goBack(); }
function generateCode(){ const code='ART-'+Date.now().toString(36).toUpperCase().slice(-6); document.getElementById('a-code').value=code; generateQRPreview(code); }
window.addEventListener('DOMContentLoaded',()=>{ const ci=document.getElementById('a-code'); if(ci) ci.addEventListener('input',()=>{ const v=ci.value.trim(); if(v) generateQRPreview(v); else document.getElementById('qr-preview-card').style.display='none'; }); });
function generateQRPreview(text){ if(!text) return; const el=document.getElementById('qr-gen-el'); el.innerHTML=''; qrFormInst=new QRCode(el,{text:JSON.stringify({codigo:text,app:'Inventario Pro'}),width:160,height:160,colorDark:'#111',colorLight:'#fff',correctLevel:QRCode.CorrectLevel.H}); document.getElementById('qr-preview-card').style.display='block'; }
function downloadQR(){ const c=document.querySelector('#qr-gen-el canvas'); if(!c) return; const a=document.createElement('a'); a.download='QR-'+(document.getElementById('a-code').value||'art')+'.png'; a.href=c.toDataURL(); a.click(); }
function handlePhotos(e){ const files=Array.from(e.target.files); if(addPhotos.length+files.length>6){ showToast('Máximo 6 fotos'); return; } files.forEach(f=>{ const r=new FileReader(); r.onload=ev=>{ addPhotos.push({file:f,preview:ev.target.result}); renderPhotosGrid(); }; r.readAsDataURL(f); }); e.target.value=''; }
function renderPhotosGrid(){ const g=document.getElementById('photos-preview'); if(!addPhotos.length){ g.style.display='none'; return; } g.style.display='grid'; g.innerHTML=addPhotos.map((p,i)=>`<div class="photo-thumb"><img src="${p.preview}" alt="foto"><button class="photo-del" onclick="removePhoto(${i})"><i class="ti ti-x"></i></button></div>`).join(''); }
function removePhoto(i){ addPhotos.splice(i,1); renderPhotosGrid(); }

async function saveArticulo(){
  if(currentUser.rol==='viewer'){ showToast('Sin permisos.'); return; }
  const nombre=(document.getElementById('a-name').value||'').trim();
  if(!nombre){ showToast('Ingresa el nombre.'); return; }
  const btn=document.getElementById('btn-save'), prog=document.getElementById('form-progress');
  btn.disabled=true; prog.style.display='flex'; setProgress('Guardando...');
  try {
    const lugarId=document.getElementById('a-lugar').value||null;
    const payload={ lugar_id:lugarId, codigo:(document.getElementById('a-code').value||'').trim()||null, nombre, categoria:(document.getElementById('a-cat').value||'').trim()||null, cantidad:parseInt(document.getElementById('a-qty').value)||1, estado:document.getElementById('a-est').value||'Operativo', precio:parseFloat(document.getElementById('a-price').value)||null, fecha_adq:document.getElementById('a-date').value||null, observaciones:(document.getElementById('a-obs').value||'').trim()||null, creado_por:currentUser.nombre };
    let artId;
    if(editingId){
      const {error}=await sb.from('articulos').update(payload).eq('id',editingId); if(error) throw error; artId=editingId;
      const idx=inventory.findIndex(i=>i.id===editingId); const lug=lugares.find(l=>l.id===lugarId);
      if(idx>=0) inventory[idx]={...inventory[idx],...payload,lugar_nombre:lug?.nombre||null,lugar_icono:lug?.icono||null,lugar_color:lug?.color||null};
    } else {
      const {data,error}=await sb.from('articulos').insert(payload).select().single(); if(error) throw error; artId=data.id;
      const lug=lugares.find(l=>l.id===lugarId);
      inventory.unshift({...data,fotos:[],lugar_nombre:lug?.nombre||null,lugar_icono:lug?.icono||null,lugar_color:lug?.color||null});
    }
    const fotoURLs=[];
    for(let i=0;i<addPhotos.length;i++){
      setProgress(`Subiendo foto ${i+1} de ${addPhotos.length}...`);
      const f=addPhotos[i].file; const ext=f.name.split('.').pop().toLowerCase()||'jpg'; const path=`${artId}/${Date.now()}_${i}.${ext}`;
      const {error:upErr}=await sb.storage.from(STORAGE_BUCKET).upload(path,f,{contentType:f.type,upsert:true}); if(upErr){ console.warn(upErr); continue; }
      const url=storageUrl(path); fotoURLs.push(url); await sb.from('fotos').insert({articulo_id:artId,storage_path:path,url,orden:i});
    }
    const artIdx=inventory.findIndex(i=>i.id===artId); if(artIdx>=0) inventory[artIdx].fotos=[...(inventory[artIdx].fotos||[]),...fotoURLs];
    updateCount(); fillDataLists(); editingId=null; addPhotos=[]; renderPhotosGrid();
    showToast('✓ Artículo guardado'); goScreen('lugares');
  } catch(e){ console.error(e); showToast('Error al guardar.'); }
  finally{ btn.disabled=false; prog.style.display='none'; }
}
function setProgress(t){ document.getElementById('fp-txt').textContent=t; }

// ── MODAL DETALLE ─────────────────────────────────
function openDetail(id){
  const item=inventory.find(i=>i.id===id); if(!item) return; modalItemId=id;
  document.getElementById('m-img-area').innerHTML=item.fotos&&item.fotos.length?`<img src="${item.fotos[0]}" style="width:100%;height:220px;object-fit:cover" alt="${item.nombre}">`:`<div style="width:100%;height:90px;background:var(--bg2);display:flex;align-items:center;justify-content:center"><i class="ti ti-photo" style="font-size:40px;color:var(--ink4)"></i></div>`;
  const lt=document.getElementById('m-lugar-tag');
  if(item.lugar_nombre){ lt.style.display='inline-flex'; lt.innerHTML=`<i class="ti ${item.lugar_icono||'ti-map-pin'}" aria-hidden="true"></i>${item.lugar_nombre}`; lt.style.background=hexToLight(item.lugar_color||'#111'); lt.style.color=item.lugar_color||'#111'; }
  else lt.style.display='none';
  document.getElementById('m-code-tag').textContent=item.codigo||'Sin código';
  document.getElementById('m-title').textContent=item.nombre;
  document.getElementById('m-meta').textContent=item.categoria||'Sin categoría';
  document.getElementById('m-badges').innerHTML=estadoBadge(item.estado)+`<span class="ebadge" style="background:var(--bg2);color:var(--ink2)">${item.cantidad} unidad${item.cantidad!==1?'es':''}</span>`+(item.precio?`<span class="ebadge" style="background:var(--bg2);color:var(--ink2)">$${Number(item.precio).toLocaleString('es-CL')}</span>`:'');
  document.getElementById('m-obs').textContent=item.observaciones||'';
  let extra=''; if(item.fecha_adq) extra+=`<div class="m-extra-row"><i class="ti ti-calendar-plus"></i>Adquirido: <strong>${fmtDate(item.fecha_adq)}</strong></div>`; if(item.creado_por) extra+=`<div class="m-extra-row"><i class="ti ti-user"></i>Registrado por: <strong>${item.creado_por}</strong></div>`; document.getElementById('m-extra').innerHTML=extra;
  document.getElementById('m-photos').innerHTML=item.fotos&&item.fotos.length>1?`<div class="m-section-title">Fotos (${item.fotos.length})</div><div class="modal-photos">${item.fotos.map(f=>`<img src="${f}" alt="foto">`).join('')}</div>`:'';
  const qrEl=document.getElementById('m-qr'); qrEl.innerHTML='';
  qrModalInst=new QRCode(qrEl,{text:JSON.stringify({codigo:item.codigo||item.id,nombre:item.nombre,app:'Inventario Pro'}),width:160,height:160,colorDark:'#111',colorLight:'#fff',correctLevel:QRCode.CorrectLevel.H});
  openModal('m-detail');
}
function dlModalQR(){ const c=document.querySelector('#m-qr canvas'); if(!c) return; const item=inventory.find(i=>i.id===modalItemId); const a=document.createElement('a'); a.download='QR-'+(item?item.codigo||item.id:'art')+'.png'; a.href=c.toDataURL(); a.click(); }
function editCurrent(){ if(currentUser.rol==='viewer'){ showToast('Sin permisos.'); return; } const item=inventory.find(i=>i.id===modalItemId); if(!item) return; closeModal('m-detail'); editingId=modalItemId; goScreen('add'); setTimeout(()=>populateForm(item),200); }
function populateForm(item){ document.getElementById('a-code').value=item.codigo||''; document.getElementById('a-name').value=item.nombre||''; document.getElementById('a-cat').value=item.categoria||''; document.getElementById('a-qty').value=item.cantidad||1; document.getElementById('a-est').value=item.estado||'Operativo'; document.getElementById('a-price').value=item.precio||''; document.getElementById('a-date').value=item.fecha_adq||''; document.getElementById('a-obs').value=item.observaciones||''; document.getElementById('a-lugar').value=item.lugar_id||''; document.getElementById('hdr-title').textContent='Editar artículo'; document.getElementById('save-label').textContent='Guardar cambios'; if(item.codigo) generateQRPreview(item.codigo); addPhotos=[]; renderPhotosGrid(); }
async function editEstado(){ if(currentUser.rol==='viewer'){ showToast('Sin permisos.'); return; } const item=inventory.find(i=>i.id===modalItemId); if(!item) return; const estados=['Operativo','Mantención','Revisión','Dado de baja']; const v=prompt(`Estado de "${item.nombre}":\n1. Operativo\n2. Mantención\n3. Revisión\n4. Dado de baja\n\nActual: ${item.estado}\nIngresa número (1-4):`,estados.indexOf(item.estado)+1); if(!v) return; const n=parseInt(v)-1; if(n<0||n>3){ showToast('Opción inválida'); return; } const {error}=await sb.from('articulos').update({estado:estados[n]}).eq('id',item.id); if(error){ showToast('Error.'); return; } item.estado=estados[n]; closeModal('m-detail'); renderLugarItems(); renderInventario(); renderLugares(); showToast('Estado actualizado'); }
async function deleteItem(){ if(currentUser.rol==='viewer'){ showToast('Sin permisos.'); return; } const item=inventory.find(i=>i.id===modalItemId); if(!item) return; if(!confirm(`¿Eliminar "${item.nombre}"?`)) return; for(const url of(item.fotos||[])){ const path=url.split(`/${STORAGE_BUCKET}/`)[1]; if(path) await sb.storage.from(STORAGE_BUCKET).remove([path]); } const {error}=await sb.from('articulos').delete().eq('id',item.id); if(error){ showToast('Error.'); return; } inventory=inventory.filter(i=>i.id!==modalItemId); closeModal('m-detail'); updateCount(); renderLugarItems(); renderInventario(); renderLugares(); showToast('Artículo eliminado'); }

// ── GESTIÓN LUGARES ───────────────────────────────
const ICONOS=['ti-building-warehouse','ti-building','ti-truck','ti-tool','ti-archive','ti-box','ti-car','ti-device-laptop','ti-shirt','ti-packages','ti-map-pin','ti-home'];
const COLORES=['#111111','#CC2229','#185FA5','#1A8A5A','#C07A10','#7B5EA7','#D85A30','#444444'];

function showLugaresAdmin(){ closeUM(); goScreen('lugares-admin'); }
function openAddLugar(){ showLugaresAdmin(); }
function renderIconPicker(){ document.getElementById('icon-picker').innerHTML=ICONOS.map(ic=>`<button class="ip-btn${ic===document.getElementById('nl-icono').value?' active':''}" onclick="selectIcono('${ic}')"><i class="ti ${ic}" aria-hidden="true"></i></button>`).join(''); }
function selectIcono(ic){ document.getElementById('nl-icono').value=ic; document.querySelectorAll('.ip-btn').forEach(b=>b.classList.toggle('active',b.querySelector('i').className.includes(ic))); }
function renderColorPicker(){ document.getElementById('color-picker').innerHTML=COLORES.map(c=>`<div class="cp-dot${c===document.getElementById('nl-color').value?' active':''}" style="background:${c}" onclick="selectColor('${c}')"></div>`).join(''); }
function selectColor(c){ document.getElementById('nl-color').value=c; document.querySelectorAll('.cp-dot').forEach(d=>d.classList.toggle('active',d.style.background===c||d.style.backgroundColor.replace(/ /g,'')===c.replace(/ /g,''))); }

async function saveLugar(){
  const nombre=(document.getElementById('nl-nombre').value||'').trim();
  const err=m=>{document.getElementById('nl-err').style.display='flex';document.getElementById('nl-err-txt').textContent=m;};
  if(!nombre){ err('Ingresa el nombre del lugar.'); return; }
  const payload={nombre,descripcion:(document.getElementById('nl-desc').value||'').trim()||null,icono:document.getElementById('nl-icono').value||'ti-building-warehouse',color:document.getElementById('nl-color').value||'#111111',orden:lugares.length+1};
  const {data,error}=await sb.from('lugares').insert(payload).select().single();
  if(error){ error.code==='23505'?err('Ese nombre ya existe.'):err('Error al crear.'); return; }
  lugares.push(data); ['nl-nombre','nl-desc'].forEach(id=>document.getElementById(id).value=''); document.getElementById('nl-err').style.display='none';
  fillDataLists(); renderLugaresAdmin(); renderLugares(); showToast('✓ Lugar creado');
}
function renderLugaresAdmin(){
  const body=document.getElementById('lugares-admin-list');
  if(!lugares.length){ body.innerHTML='<div class="empty-state"><i class="ti ti-map-pin"></i><p>Sin lugares aún.</p></div>'; return; }
  body.innerHTML=lugares.map(l=>{ const cnt=inventory.filter(i=>i.lugar_id===l.id).length; return `<div class="lugar-admin-card"><div class="lac-icon" style="background:${hexToLight(l.color||'#111')}"><i class="ti ${l.icono||'ti-building-warehouse'}" style="color:${l.color||'#111'};font-size:18px" aria-hidden="true"></i></div><div class="lac-info"><div class="lac-name">${l.nombre}</div>${l.descripcion?`<div class="lac-desc">${l.descripcion}</div>`:''}</div><div class="lac-right"><span class="lac-cnt">${cnt} art.</span><button class="btn-del-lugar" onclick="deleteLugar('${l.id}')"><i class="ti ti-trash"></i></button></div></div>`; }).join('');
}
async function deleteLugar(id){ const l=lugares.find(x=>x.id===id); if(!l) return; const cnt=inventory.filter(i=>i.lugar_id===id).length; if(!confirm(`¿Eliminar "${l.nombre}"?${cnt>0?`\n${cnt} artículo${cnt>1?'s':''} quedarán sin lugar.`:''}`)) return; const {error}=await sb.from('lugares').delete().eq('id',id); if(error){ showToast('Error.'); return; } lugares=lugares.filter(x=>x.id!==id); inventory.forEach(i=>{ if(i.lugar_id===id){ i.lugar_id=null; i.lugar_nombre=null; } }); fillDataLists(); renderLugaresAdmin(); renderLugares(); showToast('Lugar eliminado'); }

// ── ESTADÍSTICAS ──────────────────────────────────
function renderStats(){
  document.getElementById('st-total').textContent=inventory.length;
  document.getElementById('st-op').textContent=inventory.filter(i=>i.estado==='Operativo').length;
  document.getElementById('st-mant').textContent=inventory.filter(i=>['Mantención','Revisión'].includes(i.estado)).length;
  document.getElementById('st-baja').textContent=inventory.filter(i=>i.estado==='Dado de baja').length;
  const row=(name,val,sub)=>`<div class="stat-row"><div><div class="stat-row-name">${name}</div>${sub?`<div style="font-size:11px;color:var(--ink3)">${sub}</div>`:''}</div><span class="stat-row-val">${val}</span></div>`;
  document.getElementById('st-lugares').innerHTML=lugares.length?lugares.map(l=>row(l.nombre,inventory.filter(i=>i.lugar_id===l.id).length+' art.',l.descripcion||'')).join(''):'<p style="font-size:13px;color:var(--ink3)">Sin lugares.</p>';
  const cats={}; inventory.forEach(i=>{ if(i.categoria) cats[i.categoria]=(cats[i.categoria]||0)+1; }); document.getElementById('st-cats').innerHTML=Object.keys(cats).length?Object.entries(cats).sort((a,b)=>b[1]-a[1]).map(([c,n])=>row(c,n+' art.')).join(''):'<p style="font-size:13px;color:var(--ink3)">Sin datos.</p>';
  const noOp=inventory.filter(i=>i.estado!=='Operativo'); document.getElementById('st-noOp').innerHTML=noOp.length?noOp.map(i=>`<div class="stat-row"><div><div class="stat-row-name">${i.nombre}</div><div style="font-size:11px;color:var(--ink3)">${i.lugar_nombre||'Sin lugar'}</div></div>${estadoBadge(i.estado)}</div>`).join(''):'<p style="font-size:13px;color:var(--ink3)">✓ Todo operativo.</p>';
}

// ── CSV ───────────────────────────────────────────
function exportCSV(){ const h=['Código','Nombre','Lugar','Categoría','Cantidad','Estado','Precio','Fecha Adq.','Observaciones','Creado por']; const rows=inventory.map(i=>[i.codigo||'',i.nombre,i.lugar_nombre||'',i.categoria||'',i.cantidad,i.estado,i.precio||'',fmtDate(i.fecha_adq),(i.observaciones||'').replace(/,/g,';'),i.creado_por||'']); const csv=[h,...rows].map(r=>r.map(v=>`"${v}"`).join(',')).join('\n'); const a=document.createElement('a'); a.download=`Inventario_${new Date().toISOString().slice(0,10)}.csv`; a.href=URL.createObjectURL(new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8;'})); a.click(); showToast('✓ CSV exportado'); }

// ── CONTRASEÑA ────────────────────────────────────
function showChgPass(){ closeUM(); ['cp-old','cp-new','cp-conf'].forEach(id=>document.getElementById(id).value=''); document.getElementById('cp-err').style.display='none'; openModal('m-pass'); }
async function doChgPass(){ const o=document.getElementById('cp-old').value,n=document.getElementById('cp-new').value,c=document.getElementById('cp-conf').value; const err=m=>{document.getElementById('cp-err').style.display='flex';document.getElementById('cp-err-txt').textContent=m;}; if(!o||!n||!c){err('Completa todos los campos.');return;} if(n.length<8){err('Mínimo 8 caracteres.');return;} if(n!==c){err('No coinciden.');return;} const oh=await sha256(o); const def={admin:'Admin123*',editor:'Editor123*'}; if(oh!==currentUser.pass_hash&&!(def[currentUser.usuario]&&o===def[currentUser.usuario])){ err('Contraseña actual incorrecta.'); return; } const nh=await sha256(n); const {error}=await sb.from('usuarios').update({pass_hash:nh}).eq('id',currentUser.id); if(error){err('Error.');return;} currentUser.pass_hash=nh; sessionStorage.setItem('inv_session',JSON.stringify(currentUser)); closeModal('m-pass'); showToast('✓ Contraseña actualizada'); }

// ── USUARIOS ──────────────────────────────────────
function showUsersPanel(){ closeUM(); renderUsersList(); goScreen('users'); }
async function renderUsersList(){ const {data}=await sb.from('usuarios').select('*').order('creado_at'); document.getElementById('users-list-panel').innerHTML=`<div class="users-list-card">`+(data||[]).map(u=>`<div class="user-row"><div><div class="ur-name">${u.nombre}</div><div class="ur-meta">@${u.usuario}</div></div><div style="display:flex;align-items:center;gap:8px"><span class="role-pill rp-${u.rol}">${roleLabel(u.rol)}</span>${u.id!==currentUser.id?`<button class="btn-del-user" onclick="delUser('${u.id}')"><i class="ti ti-trash"></i></button>`:''}</div></div>`).join('')+`</div>`; }
async function addUser(){ const nombre=(document.getElementById('nu-name').value||'').trim(),usuario=(document.getElementById('nu-user').value||'').trim().toLowerCase(),rol=document.getElementById('nu-rol').value,pass=document.getElementById('nu-pass').value; const err=m=>{document.getElementById('nu-err').style.display='flex';document.getElementById('nu-err-txt').textContent=m;}; if(!nombre||!usuario||!pass){err('Completa todos los campos.');return;} if(pass.length<8){err('Mínimo 8 caracteres.');return;} if(!/^[a-z0-9_]+$/.test(usuario)){err('Usuario: solo letras, números y guion bajo.');return;} const ph=await sha256(pass); const {error}=await sb.from('usuarios').insert({nombre,usuario,pass_hash:ph,rol}); if(error){ error.code==='23505'?err('Ese usuario ya existe.'):err('Error.'); return; } ['nu-name','nu-user','nu-pass'].forEach(id=>document.getElementById(id).value=''); document.getElementById('nu-err').style.display='none'; renderUsersList(); showToast('✓ Usuario creado'); }
async function delUser(id){ const {data:u}=await sb.from('usuarios').select('nombre,usuario').eq('id',id).single(); if(!u) return; if(!confirm(`¿Eliminar a "${u.nombre}"?`)) return; await sb.from('usuarios').delete().eq('id',id); renderUsersList(); showToast('Usuario eliminado'); }

// ── MODALES ───────────────────────────────────────
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }
function maybeCloseModal(id,e){ if(e.target===document.getElementById(id)) closeModal(id); }
function toggleUM(){ const m=document.getElementById('um'),b=document.getElementById('um-back'); const open=m.style.display!=='none'; m.style.display=open?'none':'block'; b.style.display=open?'none':'block'; }
function closeUM(){ document.getElementById('um').style.display='none'; document.getElementById('um-back').style.display='none'; }

// ── UTILS ─────────────────────────────────────────
function fmtDate(d){ if(!d) return '—'; const[y,m,day]=(d.split('T')[0]||d).split('-'); return `${day}/${m}/${y}`; }
function hexToLight(hex){ try{ const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16); return `rgba(${r},${g},${b},0.12)`; } catch{ return '#F4F3F0'; } }
let toastTimer=null;
function showToast(msg){ const t=document.getElementById('toast'); t.textContent=msg; t.style.display='block'; if(toastTimer) clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.style.display='none',3000); }

// ════════════════════════════════════════════════
//  MÓDULO ENTRADAS / SALIDAS
// ════════════════════════════════════════════════

let movimientos    = [];      // cache local
let movFilter      = '';      // 'entrada' | 'salida' | ''
let currentMovTipo = 'entrada';
let movHistorialId = null;    // para ver historial de un artículo específico

// Agregar movimientos al SCREEN_MAP
SCREEN_MAP['movimientos'] = {id:'s-movimientos', title:'Movimientos', sub:'Entradas y salidas', nav:'nb-movimientos'};

// ── CARGAR MOVIMIENTOS ────────────────────────────
async function loadMovimientos(){
  const {data,error} = await sb
    .from('movimientos')
    .select('*, articulos(id,nombre,codigo,lugar_id,lugares(nombre))')
    .order('creado_at', {ascending:false})
    .limit(200);
  if(error){ console.error(error); return; }
  movimientos = (data||[]).map(m=>({
    ...m,
    art_nombre:  m.articulos?.nombre || '—',
    art_codigo:  m.articulos?.codigo || '',
    lugar_nombre: m.articulos?.lugares?.nombre || '',
  }));
}

// ── ABRIR FORMULARIO DE MOVIMIENTO ───────────────
function openMovForm(tipo){
  const item = inventory.find(i=>i.id===modalItemId);
  if(!item){ showToast('Artículo no encontrado.'); return; }
  if(currentUser.rol==='viewer'){ showToast('Sin permisos para registrar movimientos.'); return; }

  currentMovTipo = tipo;

  // Badge tipo
  const badge = document.getElementById('mf-tipo-badge');
  badge.textContent = tipo==='entrada' ? 'Entrada' : 'Salida';
  badge.className   = `mov-form-tipo ${tipo}`;

  // Nombre artículo
  document.getElementById('mf-art-nombre').textContent = item.nombre;

  // Stock actual
  document.getElementById('mf-stock-actual').textContent = item.cantidad;
  document.getElementById('mf-stock-actual').className   = `mov-stock-val ${item.cantidad<=0?'stock-low':'stock-ok'}`;

  // Etiqueta destino
  document.getElementById('mf-destino-lbl').textContent = tipo==='salida' ? 'Destino' : 'Procedencia';
  document.getElementById('mf-destino').placeholder     = tipo==='salida' ? 'A dónde va el artículo' : 'De dónde proviene';

  // Botón
  document.getElementById('mf-btn-txt').textContent = tipo==='entrada' ? 'Registrar entrada' : 'Registrar salida';
  const btn = document.getElementById('btn-mov');
  btn.style.background = tipo==='entrada' ? '#1A8A5A' : '#C0281A';

  // Limpiar campos
  document.getElementById('mf-cantidad').value   = '1';
  document.getElementById('mf-motivo').value     = '';
  document.getElementById('mf-responsable').value= '';
  document.getElementById('mf-destino').value    = '';
  document.getElementById('mf-notas').value      = '';
  document.getElementById('mf-err').style.display= 'none';
  document.getElementById('mf-stock-preview').style.display= 'none';

  // Preview stock en vivo
  document.getElementById('mf-cantidad').oninput = updateStockPreview;

  openModal('m-mov');
}

function updateStockPreview(){
  const item    = inventory.find(i=>i.id===modalItemId); if(!item) return;
  const cant    = parseInt(document.getElementById('mf-cantidad').value)||0;
  const nuevo   = currentMovTipo==='entrada' ? item.cantidad+cant : item.cantidad-cant;
  const preview = document.getElementById('mf-stock-preview');
  const val     = document.getElementById('mf-stock-nuevo');
  preview.style.display = cant>0 ? 'flex' : 'none';
  val.textContent = nuevo;
  val.className   = `mov-stock-val ${nuevo<0?'stock-low':nuevo===0?'stock-low':'stock-ok'}`;
}

// ── GUARDAR MOVIMIENTO ────────────────────────────
async function saveMovimiento(){
  const item   = inventory.find(i=>i.id===modalItemId); if(!item) return;
  const cant   = parseInt(document.getElementById('mf-cantidad').value)||0;
  const motivo = document.getElementById('mf-motivo').value;
  const resp   = (document.getElementById('mf-responsable').value||'').trim();
  const dest   = (document.getElementById('mf-destino').value||'').trim();
  const notas  = (document.getElementById('mf-notas').value||'').trim();

  const showErr = m=>{ document.getElementById('mf-err').style.display='flex'; document.getElementById('mf-err-txt').textContent=m; };

  if(cant<=0){ showErr('Ingresa una cantidad válida mayor a 0.'); return; }
  if(currentMovTipo==='salida' && cant>item.cantidad){
    showErr(`Stock insuficiente. Stock actual: ${item.cantidad} unidades.`); return;
  }

  const btn=document.getElementById('btn-mov'); btn.disabled=true;

  try {
    // 1. Insertar movimiento
    const {error:movErr} = await sb.from('movimientos').insert({
      articulo_id:    item.id,
      tipo:           currentMovTipo,
      cantidad:       cant,
      motivo:         motivo||null,
      responsable:    resp||null,
      destino:        dest||null,
      notas:          notas||null,
      registrado_por: currentUser.nombre,
    });
    if(movErr) throw movErr;

    // 2. Actualizar stock del artículo
    const nuevoStock = currentMovTipo==='entrada'
      ? item.cantidad + cant
      : item.cantidad - cant;

    const {error:updErr} = await sb.from('articulos')
      .update({ cantidad: nuevoStock })
      .eq('id', item.id);
    if(updErr) throw updErr;

    // 3. Actualizar cache local
    item.cantidad = nuevoStock;

    // 4. Agregar al cache de movimientos
    movimientos.unshift({
      id:            'local-'+Date.now(),
      articulo_id:   item.id,
      tipo:          currentMovTipo,
      cantidad:      cant,
      motivo:        motivo||null,
      responsable:   resp||null,
      destino:       dest||null,
      notas:         notas||null,
      registrado_por:currentUser.nombre,
      creado_at:     new Date().toISOString(),
      art_nombre:    item.nombre,
      art_codigo:    item.codigo||'',
      lugar_nombre:  item.lugar_nombre||'',
    });

    closeModal('m-mov');
    // Reabrir modal detalle con datos actualizados
    openDetail(item.id);
    renderLugarItems(); renderInventario(); renderLugares();
    showToast(`✓ ${currentMovTipo==='entrada'?'Entrada':'Salida'} registrada · Stock: ${nuevoStock}`);

  } catch(e){
    console.error(e); showErr('Error al guardar. Intenta de nuevo.');
  } finally { btn.disabled=false; }
}

// ── HISTORIAL RÁPIDO EN MODAL ─────────────────────
async function loadHistorialModal(artId){
  const {data} = await sb
    .from('movimientos')
    .select('*')
    .eq('articulo_id', artId)
    .order('creado_at', {ascending:false})
    .limit(5);
  const el = document.getElementById('m-historial');
  if(!data||!data.length){
    el.innerHTML='<p style="font-size:13px;color:var(--ink3);padding:4px 0 8px">Sin movimientos registrados.</p>';
    return;
  }
  el.innerHTML=data.map(m=>movItemHTML(m)).join('');
}

function movItemHTML(m, showArt=false){
  const fecha = fmtDate(m.creado_at);
  const hora  = m.creado_at ? new Date(m.creado_at).toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'}) : '';
  const qty   = m.tipo==='entrada' ? `+${m.cantidad}` : `-${m.cantidad}`;
  const meta  = [m.responsable, m.destino, m.registrado_por ? `Reg: ${m.registrado_por}` : ''].filter(Boolean).join(' · ');
  return `<div class="mov-item">
    <div class="mov-icon ${m.tipo}"><i class="ti ${m.tipo==='entrada'?'ti-arrow-bar-to-down':'ti-arrow-bar-up'}" aria-hidden="true"></i></div>
    <div class="mov-body">
      <div class="mov-top">
        ${showArt ? `<span class="mov-art">${m.art_nombre||'—'}</span>` : `<span class="mov-art">${m.tipo==='entrada'?'Entrada':'Salida'}</span>`}
        <span class="mov-qty ${m.tipo}">${qty} uds.</span>
      </div>
      <div class="mov-meta">${fecha} ${hora}${meta?' · '+meta:''}</div>
      ${m.motivo?`<span class="mov-motivo">${m.motivo}</span>`:''}
      ${m.notas?`<div style="font-size:12px;color:var(--ink3);margin-top:3px">${m.notas}</div>`:''}
    </div>
  </div>`;
}

// ── VER TODO EL HISTORIAL DE UN ARTÍCULO ──────────
function verTodoHistorial(){
  const item = inventory.find(i=>i.id===modalItemId); if(!item) return;
  movHistorialId = item.id;
  closeModal('m-detail');
  goScreen('movimientos');
  setTimeout(()=>{
    document.getElementById('mov-search').value = item.nombre;
    renderMovimientos();
  },200);
}

// ── PANTALLA MOVIMIENTOS ──────────────────────────
function setMovFilter(v,el){
  movFilter=v;
  document.querySelectorAll('.mov-filter-row .chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
  renderMovimientos();
}

async function renderMovimientos(){
  // Cargar si el cache está vacío
  if(!movimientos.length) await loadMovimientos();

  const q=(document.getElementById('mov-search').value||'').toLowerCase();
  const items=movimientos.filter(m=>
    (!movFilter||m.tipo===movFilter)&&
    (!q||(m.art_nombre||'').toLowerCase().includes(q)||(m.responsable||'').toLowerCase().includes(q)||(m.motivo||'').toLowerCase().includes(q)||(m.art_codigo||'').toLowerCase().includes(q))
  );

  // Contadores
  document.getElementById('ms-entradas').textContent=movimientos.filter(m=>m.tipo==='entrada').length;
  document.getElementById('ms-salidas').textContent =movimientos.filter(m=>m.tipo==='salida').length;

  const body=document.getElementById('mov-list');
  if(!items.length){
    body.innerHTML=`<div class="empty-state"><i class="ti ti-arrow-left-right"></i><p>${movimientos.length?'Sin resultados.':'Sin movimientos registrados aún.'}</p></div>`;
    return;
  }
  body.innerHTML=items.map(m=>movItemHTML(m,true)).join('');
}

// ── PATCH: openDetail para cargar historial ───────
// Guardamos referencia a la función original y la extendemos
const _origOpenDetail = openDetail;
window.openDetail = function(id){
  _origOpenDetail(id);
  // Cargar historial con pequeño delay para que el modal abra primero
  setTimeout(()=>loadHistorialModal(id), 150);
};

// ── PATCH: goScreen para movimientos ─────────────
const _origGoScreen = goScreen;
window.goScreen = function(s){
  _origGoScreen(s);
  if(s==='movimientos') renderMovimientos();
};


// ════════════════════════════════════════════════
//  EXPORTAR EXCEL (.xlsx) — completo o por lugar
// ════════════════════════════════════════════════
function exportExcel(lugarId) {
  const items = lugarId
    ? inventory.filter(i => i.lugar_id === lugarId)
    : inventory;

  const lugar = lugarId ? lugares.find(l => l.id === lugarId) : null;
  const nombreArchivo = lugar
    ? `InvenControl_${lugar.nombre.replace(/\s+/g,'-')}`
    : 'InvenControl_Completo';

  // Encabezados
  const headers = [
    'Código', 'Nombre', 'Lugar', 'Categoría', 'Cantidad',
    'Estado', 'Precio', 'Fecha Adquisición', 'Observaciones', 'Registrado por'
  ];

  // Filas
  const rows = items.map(i => [
    i.codigo || '',
    i.nombre || '',
    i.lugar_nombre || 'Sin lugar',
    i.categoria || '',
    i.cantidad || 0,
    i.estado || '',
    i.precio || '',
    fmtDate(i.fecha_adq),
    i.observaciones || '',
    i.creado_por || ''
  ]);

  // Crear workbook
  const wb = XLSX.utils.book_new();

  // Hoja principal — todos los artículos
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);

  // Estilos de ancho de columnas
  ws['!cols'] = [
    {wch:14},{wch:30},{wch:18},{wch:18},{wch:10},
    {wch:16},{wch:12},{wch:16},{wch:30},{wch:18}
  ];

  XLSX.utils.book_append_sheet(wb, ws, lugar ? lugar.nombre : 'Inventario');

  // Si es completo → agregar una hoja por cada lugar
  if (!lugarId && lugares.length) {
    lugares.forEach(l => {
      const arts = inventory.filter(i => i.lugar_id === l.id);
      if (!arts.length) return;
      const wsL = XLSX.utils.aoa_to_sheet([
        headers,
        ...arts.map(i => [
          i.codigo||'', i.nombre||'', l.nombre,
          i.categoria||'', i.cantidad||0, i.estado||'',
          i.precio||'', fmtDate(i.fecha_adq),
          i.observaciones||'', i.creado_por||''
        ])
      ]);
      wsL['!cols'] = [{wch:14},{wch:30},{wch:18},{wch:18},{wch:10},{wch:16},{wch:12},{wch:16},{wch:30},{wch:18}];
      XLSX.utils.book_append_sheet(wb, wsL, l.nombre.slice(0,31));
    });
  }

  // Descargar
  XLSX.writeFile(wb, `${nombreArchivo}_${new Date().toISOString().slice(0,10)}.xlsx`);
  showToast('✓ Excel descargado');
}

// Renderizar botones Excel por lugar en Stats
function renderExcelBtns() {
  const el = document.getElementById('excel-btns');
  if (!el) return;
  if (!lugares.length) { el.innerHTML = ''; return; }
  el.innerHTML = lugares.map(l => {
    const cnt = inventory.filter(i => i.lugar_id === l.id).length;
    if (!cnt) return '';
    return `<button class="btn-excel" style="width:100%;margin-bottom:7px" onclick="exportExcel('${l.id}')">
      <i class="ti ti-download"></i>${l.nombre} (${cnt} artículos)
    </button>`;
  }).join('');
}

// Patch renderStats para incluir botones Excel
const _origRenderStats = renderStats;
window.renderStats = function() {
  _origRenderStats();
  renderExcelBtns();
};


// ════════════════════════════════════════════════
//  ESCÁNER — Cámara nativa iOS + jsQR
//  Funciona en iPhone Safari sin permisos especiales
// ════════════════════════════════════════════════

let scanFoundId5 = null;
let scanType5    = 'qr';

window.startScan = function() { reanudarScan5(); };
window.stopScan  = function() { scanActive = false; };

window.setScanType = function(type) {
  scanType5 = type;
  document.getElementById('st-qr').classList.toggle('active',  type === 'qr');
  document.getElementById('st-bar').classList.toggle('active', type === 'bar');
  const ico   = document.getElementById('snb-ico');
  const title = document.getElementById('snb-title');
  if (type === 'qr') {
    if(ico)   ico.className     = 'ti ti-qrcode';
    if(title) title.textContent = 'Escanear código QR';
  } else {
    if(ico)   ico.className     = 'ti ti-barcode';
    if(title) title.textContent = 'Escanear código de barras';
  }
};

window.processScanImage = function(event) {
  const file = event.target.files[0];
  if (!file) return;
  event.target.value = '';

  const box  = document.getElementById('scan-native-box');
  const proc = document.getElementById('scan-processing');
  const err  = document.getElementById('scan-error');
  if(box)  box.style.display  = 'none';
  if(proc) proc.style.display = 'block';
  if(err)  err.style.display  = 'none';
  document.getElementById('scan-found').style.display    = 'none';
  document.getElementById('scan-notfound').style.display = 'none';

  const reader = new FileReader();
  reader.onload = function(e) {
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement('canvas');
      canvas.width  = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const result = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'attemptBoth'
      });
      if(proc) proc.style.display = 'none';
      if (result && result.data) {
        procesarCodigo5(result.data);
      } else {
        if(box) box.style.display = 'block';
        if(err) {
          err.style.display = 'block';
          document.getElementById('scan-error-msg').textContent =
            'No se detectó ningún código. Intenta con mejor luz o más cerca.';
        }
      }
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
};

function procesarCodigo5(data) {
  if (navigator.vibrate) navigator.vibrate(100);

  if (scanForFieldCb) {
    let codigo = data;
    try { const o = JSON.parse(data); codigo = o.codigo || o.serial || data; } catch {}
    scanForFieldCb(codigo);
    scanForFieldCb = null;
    goBack();
    showToast('✓ Código capturado: ' + codigo);
    return;
  }

  let codigo = data;
  try { const o = JSON.parse(data); codigo = o.codigo || o.serial || data; } catch {}

  const found = inventory.find(i =>
    i.codigo === codigo || i.codigo === data ||
    (i.codigo && (data.includes(i.codigo) || codigo.includes(i.codigo)))
  );

  const box = document.getElementById('scan-native-box');
  if(box) box.style.display = 'none';

  if (found) {
    scanFoundId5 = found.id;
    document.getElementById('sf-nombre').textContent = found.nombre;
    document.getElementById('sf-meta').textContent   =
      [found.lugar_nombre, found.categoria, found.estado].filter(Boolean).join(' · ');
    document.getElementById('scan-found').style.display    = 'flex';
    document.getElementById('scan-notfound').style.display = 'none';
  } else {
    document.getElementById('snf-code').textContent        = codigo;
    document.getElementById('scan-notfound').style.display = 'block';
    document.getElementById('scan-found').style.display    = 'none';
  }
}

window.buscarManual = function() {
  const codigo = (document.getElementById('manual-code').value || '').trim();
  if (!codigo) { showToast('Ingresa un código'); return; }
  const found = inventory.find(i => (i.codigo||'').toLowerCase() === codigo.toLowerCase());
  const box = document.getElementById('scan-native-box');
  if(box) box.style.display = 'none';
  document.getElementById('scan-error').style.display = 'none';
  if (found) {
    scanFoundId5 = found.id;
    document.getElementById('sf-nombre').textContent = found.nombre;
    document.getElementById('sf-meta').textContent   =
      [found.lugar_nombre, found.categoria, found.estado].filter(Boolean).join(' · ');
    document.getElementById('scan-found').style.display    = 'flex';
    document.getElementById('scan-notfound').style.display = 'none';
  } else {
    document.getElementById('snf-code').textContent        = codigo;
    document.getElementById('scan-notfound').style.display = 'block';
    document.getElementById('scan-found').style.display    = 'none';
  }
};

window.abrirDesdeEscan = function() {
  const id = scanFoundId5;
  goBack();
  setTimeout(() => openDetail(id), 300);
};

window.crearDesdeEscan = function() {
  const codigo = document.getElementById('snf-code').textContent;
  goScreen('add');
  setTimeout(() => {
    document.getElementById('a-code').value = codigo;
    generateQRPreview(codigo);
    showToast('Código cargado — completa los datos');
  }, 300);
};

window.reanudarScan = reanudarScan5;
function reanudarScan5() {
  const box = document.getElementById('scan-native-box');
  if(box) box.style.display = 'block';
  document.getElementById('scan-found').style.display      = 'none';
  document.getElementById('scan-notfound').style.display   = 'none';
  document.getElementById('scan-processing').style.display = 'none';
  document.getElementById('scan-error').style.display      = 'none';
  const mc = document.getElementById('manual-code');
  if(mc) mc.value = '';
  scanFoundId5 = null;
  scanActive   = true;
}

// Patch goScreen
const _gsLast = window.goScreen;
window.goScreen = function(s) {
  if (s === 'scan') reanudarScan5();
  else window.stopScan();
  _gsLast(s);
};

// ════════════════════════════════════════════════
//  EXPORTAR EXCEL (.xlsx)
// ════════════════════════════════════════════════
function exportExcel(lugarId) {
  const items  = lugarId ? inventory.filter(i=>i.lugar_id===lugarId) : inventory;
  const lugar  = lugarId ? lugares.find(l=>l.id===lugarId) : null;
  const nombre = lugar ? `InvenControl_${lugar.nombre.replace(/\s+/g,'-')}` : 'InvenControl_Completo';
  const headers = ['Código','Nombre','Lugar','Categoría','Cantidad','Estado','Precio','Fecha Adq.','Observaciones','Registrado por'];
  const rows = items.map(i=>[i.codigo||'',i.nombre||'',i.lugar_nombre||'Sin lugar',i.categoria||'',i.cantidad||0,i.estado||'',i.precio||'',fmtDate(i.fecha_adq),(i.observaciones||'').replace(/,/g,';'),i.creado_por||'']);
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([headers,...rows]);
  ws['!cols']=[{wch:14},{wch:30},{wch:18},{wch:18},{wch:10},{wch:16},{wch:12},{wch:16},{wch:30},{wch:18}];
  XLSX.utils.book_append_sheet(wb, ws, lugar?lugar.nombre:'Inventario');
  if (!lugarId && lugares.length) {
    lugares.forEach(l=>{
      const arts=inventory.filter(i=>i.lugar_id===l.id); if(!arts.length) return;
      const wsL=XLSX.utils.aoa_to_sheet([headers,...arts.map(i=>[i.codigo||'',i.nombre||'',l.nombre,i.categoria||'',i.cantidad||0,i.estado||'',i.precio||'',fmtDate(i.fecha_adq),(i.observaciones||'').replace(/,/g,';'),i.creado_por||''])]);
      wsL['!cols']=[{wch:14},{wch:30},{wch:18},{wch:18},{wch:10},{wch:16},{wch:12},{wch:16},{wch:30},{wch:18}];
      XLSX.utils.book_append_sheet(wb,wsL,l.nombre.slice(0,31));
    });
  }
  XLSX.writeFile(wb,`${nombre}_${new Date().toISOString().slice(0,10)}.xlsx`);
  showToast('✓ Excel descargado');
}

function renderExcelBtns(){
  const el=document.getElementById('excel-btns'); if(!el) return;
  el.innerHTML=lugares.map(l=>{
    const cnt=inventory.filter(i=>i.lugar_id===l.id).length; if(!cnt) return '';
    return `<button class="btn-excel" style="width:100%;margin-bottom:7px" onclick="exportExcel('${l.id}')"><i class="ti ti-download"></i>${l.nombre} (${cnt} artículos)</button>`;
  }).join('');
}

const _origRenderStats2=renderStats;
window.renderStats=function(){ _origRenderStats2(); renderExcelBtns(); };

// ════════════════════════════════════════════════
//  MOVIMIENTOS
// ════════════════════════════════════════════════
let movimientos=[], movFilter='', movHistorialId=null;
SCREEN_MAP['movimientos']={id:'s-movimientos',title:'Movimientos',sub:'Entradas y salidas',nav:'nb-movimientos'};

async function loadMovimientos(){
  const {data,error}=await sb.from('movimientos').select('*, articulos(id,nombre,codigo,lugar_id,lugares(nombre))').order('creado_at',{ascending:false}).limit(200);
  if(error){console.error(error);return;}
  movimientos=(data||[]).map(m=>({...m,art_nombre:m.articulos?.nombre||'—',art_codigo:m.articulos?.codigo||'',lugar_nombre:m.articulos?.lugares?.nombre||''}));
}

function openMovForm(tipo){
  const item=inventory.find(i=>i.id===modalItemId); if(!item) return;
  if(currentUser.rol==='viewer'){showToast('Sin permisos.');return;}
  currentMovTipo=tipo;
  const badge=document.getElementById('mf-tipo-badge');
  badge.textContent=tipo==='entrada'?'Entrada':'Salida'; badge.className=`mov-form-tipo ${tipo}`;
  document.getElementById('mf-art-nombre').textContent=item.nombre;
  document.getElementById('mf-stock-actual').textContent=item.cantidad;
  document.getElementById('mf-stock-actual').className=`mov-stock-val ${item.cantidad<=0?'stock-low':'stock-ok'}`;
  document.getElementById('mf-destino-lbl').textContent=tipo==='salida'?'Destino':'Procedencia';
  document.getElementById('mf-destino').placeholder=tipo==='salida'?'A dónde va':'De dónde proviene';
  document.getElementById('mf-btn-txt').textContent=tipo==='entrada'?'Registrar entrada':'Registrar salida';
  document.getElementById('btn-mov').style.background=tipo==='entrada'?'var(--green)':'var(--red)';
  ['mf-cantidad','mf-motivo','mf-responsable','mf-destino','mf-notas'].forEach(id=>document.getElementById(id).value=id==='mf-cantidad'?'1':'');
  document.getElementById('mf-err').style.display='none';
  document.getElementById('mf-stock-preview').style.display='none';
  document.getElementById('mf-cantidad').oninput=updateStockPreview;
  openModal('m-mov');
}
let currentMovTipo='entrada';

function updateStockPreview(){
  const item=inventory.find(i=>i.id===modalItemId); if(!item) return;
  const cant=parseInt(document.getElementById('mf-cantidad').value)||0;
  const nuevo=currentMovTipo==='entrada'?item.cantidad+cant:item.cantidad-cant;
  const prev=document.getElementById('mf-stock-preview'),val=document.getElementById('mf-stock-nuevo');
  prev.style.display=cant>0?'flex':'none'; val.textContent=nuevo;
  val.className=`mov-stock-val ${nuevo<0?'stock-low':'stock-ok'}`;
}

async function saveMovimiento(){
  const item=inventory.find(i=>i.id===modalItemId); if(!item) return;
  const cant=parseInt(document.getElementById('mf-cantidad').value)||0;
  const motivo=document.getElementById('mf-motivo').value;
  const resp=(document.getElementById('mf-responsable').value||'').trim();
  const dest=(document.getElementById('mf-destino').value||'').trim();
  const notas=(document.getElementById('mf-notas').value||'').trim();
  const showErr=m=>{document.getElementById('mf-err').style.display='flex';document.getElementById('mf-err-txt').textContent=m;};
  if(cant<=0){showErr('Ingresa una cantidad válida.');return;}
  if(currentMovTipo==='salida'&&cant>item.cantidad){showErr(`Stock insuficiente. Stock actual: ${item.cantidad}.`);return;}
  const btn=document.getElementById('btn-mov'); btn.disabled=true;
  try {
    const {error:movErr}=await sb.from('movimientos').insert({articulo_id:item.id,tipo:currentMovTipo,cantidad:cant,motivo:motivo||null,responsable:resp||null,destino:dest||null,notas:notas||null,registrado_por:currentUser.nombre});
    if(movErr) throw movErr;
    const nuevoStock=currentMovTipo==='entrada'?item.cantidad+cant:item.cantidad-cant;
    const {error:updErr}=await sb.from('articulos').update({cantidad:nuevoStock}).eq('id',item.id);
    if(updErr) throw updErr;
    item.cantidad=nuevoStock;
    movimientos.unshift({id:'local-'+Date.now(),articulo_id:item.id,tipo:currentMovTipo,cantidad:cant,motivo:motivo||null,responsable:resp||null,destino:dest||null,notas:notas||null,registrado_por:currentUser.nombre,creado_at:new Date().toISOString(),art_nombre:item.nombre,art_codigo:item.codigo||'',lugar_nombre:item.lugar_nombre||''});
    closeModal('m-mov'); openDetail(item.id);
    renderLugarItems(); renderInventario(); renderLugares();
    showToast(`✓ ${currentMovTipo==='entrada'?'Entrada':'Salida'} registrada · Stock: ${nuevoStock}`);
  } catch(e){ console.error(e); showErr('Error al guardar.'); }
  finally{ btn.disabled=false; }
}

async function loadHistorialModal(artId){
  const {data}=await sb.from('movimientos').select('*').eq('articulo_id',artId).order('creado_at',{ascending:false}).limit(5);
  const el=document.getElementById('m-historial');
  if(!data||!data.length){el.innerHTML='<p style="font-size:13px;color:var(--ink3);padding:4px 0 8px">Sin movimientos registrados.</p>';return;}
  el.innerHTML=data.map(m=>movItemHTML(m)).join('');
}

function movItemHTML(m,showArt=false){
  const fecha=fmtDate(m.creado_at),hora=m.creado_at?new Date(m.creado_at).toLocaleTimeString('es-CL',{hour:'2-digit',minute:'2-digit'}):'';
  const qty=m.tipo==='entrada'?`+${m.cantidad}`:`-${m.cantidad}`;
  const meta=[m.responsable,m.destino,m.registrado_por?`Reg: ${m.registrado_por}`:''].filter(Boolean).join(' · ');
  return `<div class="mov-item"><div class="mov-icon ${m.tipo}"><i class="ti ${m.tipo==='entrada'?'ti-arrow-bar-to-down':'ti-arrow-bar-up'}"></i></div><div class="mov-body"><div class="mov-top">${showArt?`<span class="mov-art">${m.art_nombre||'—'}</span>`:`<span class="mov-art">${m.tipo==='entrada'?'Entrada':'Salida'}</span>`}<span class="mov-qty ${m.tipo}">${qty} uds.</span></div><div class="mov-meta">${fecha} ${hora}${meta?' · '+meta:''}</div>${m.motivo?`<span class="mov-motivo">${m.motivo}</span>`:''}</div></div>`;
}

function verTodoHistorial(){
  const item=inventory.find(i=>i.id===modalItemId); if(!item) return;
  closeModal('m-detail'); goScreen('movimientos');
  setTimeout(()=>{ document.getElementById('mov-search').value=item.nombre; renderMovimientos(); },200);
}

function setMovFilter(v,el){ movFilter=v; document.querySelectorAll('.mov-filter-row .chip').forEach(c=>c.classList.remove('active')); el.classList.add('active'); renderMovimientos(); }

async function renderMovimientos(){
  if(!movimientos.length) await loadMovimientos();
  const q=(document.getElementById('mov-search').value||'').toLowerCase();
  const items=movimientos.filter(m=>(!movFilter||m.tipo===movFilter)&&(!q||(m.art_nombre||'').toLowerCase().includes(q)||(m.responsable||'').toLowerCase().includes(q)||(m.motivo||'').toLowerCase().includes(q)));
  document.getElementById('ms-entradas').textContent=movimientos.filter(m=>m.tipo==='entrada').length;
  document.getElementById('ms-salidas').textContent =movimientos.filter(m=>m.tipo==='salida').length;
  const body=document.getElementById('mov-list');
  if(!items.length){body.innerHTML=`<div class="empty-state"><i class="ti ti-arrow-left-right"></i><p>${movimientos.length?'Sin resultados.':'Sin movimientos aún.'}</p></div>`;return;}
  body.innerHTML=items.map(m=>movItemHTML(m,true)).join('');
}

const _origOpenDetail2=openDetail;
window.openDetail=function(id){ _origOpenDetail2(id); setTimeout(()=>loadHistorialModal(id),150); };
