// ═══════════════════════════════════════════════════
//  CONFIGURACIÓN — InvenControl
//  Proyecto: InvenControl (Supabase)
// ═══════════════════════════════════════════════════
const SUPABASE_URL   = 'https://wkazxlwbtaymcmaoasep.supabase.co';
const SUPABASE_ANON  = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndrYXp4bHdidGF5bWNtYW9hc2VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA2ODY1MTUsImV4cCI6MjA5NjI2MjUxNX0.ypnvoSZAzMyb67Of-ClDCij2Wa3OcTadF5F05xS81No';
const STORAGE_BUCKET = 'inventario-fotos';
